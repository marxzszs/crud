# Add project specific ProGuard rules here.
# This file is intentionally left mostly empty because minifyEnabled is false.
# If you turn on code shrinking for release builds, add keep rules for
# Room entities/DAOs here if you hit reflection-related issues.
