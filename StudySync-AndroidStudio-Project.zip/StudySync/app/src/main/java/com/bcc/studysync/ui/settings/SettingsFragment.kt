package com.bcc.studysync.ui.settings

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.bcc.studysync.databinding.FragmentSettingsBinding
import com.bcc.studysync.util.Constants

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val prefs = requireContext().getSharedPreferences(
            Constants.PREFS_NAME, Context.MODE_PRIVATE
        )

        // Restore saved preferences into the UI.
        binding.switchDarkMode.isChecked = prefs.getBoolean(Constants.KEY_DARK_MODE, false)
        val sortBySubject = prefs.getBoolean(Constants.KEY_SORT_BY_SUBJECT, false)
        if (sortBySubject) {
            binding.radioSortSubject.isChecked = true
        } else {
            binding.radioSortDueDate.isChecked = true
        }

        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean(Constants.KEY_DARK_MODE, isChecked).apply()
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
        }

        binding.radioGroupSort.setOnCheckedChangeListener { _, checkedId ->
            val bySubject = checkedId == binding.radioSortSubject.id
            prefs.edit().putBoolean(Constants.KEY_SORT_BY_SUBJECT, bySubject).apply()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
