package com.bcc.studysync.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single academic task/deadline.
 *
 * [dueDate] is stored as epoch milliseconds (not a formatted String) so that
 * SQL "ORDER BY dueDate" sorts chronologically instead of alphabetically.
 */
@Entity(tableName = "tasks")
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val taskName: String,
    val courseName: String,
    val dueDate: Long,
    val isCompleted: Boolean = false
)
