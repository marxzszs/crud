package com.bcc.studysync.data

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface TaskDao {

    // ---- Create ----
    @Insert
    suspend fun insertTask(task: Task)

    // ---- Update ----
    @Update
    suspend fun updateTask(task: Task)

    // ---- Delete ----
    @Delete
    suspend fun deleteTask(task: Task)

    // ---- Read (single task, used when opening the edit screen) ----
    @Query("SELECT * FROM tasks WHERE id = :taskId LIMIT 1")
    suspend fun getTaskById(taskId: Int): Task?

    // ---- Read (lists, observed live by the UI) ----
    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY dueDate ASC")
    fun getPendingTasksByDate(): LiveData<List<Task>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY courseName ASC")
    fun getPendingTasksBySubject(): LiveData<List<Task>>

    @Query("SELECT * FROM tasks WHERE isCompleted = 1 ORDER BY dueDate DESC")
    fun getCompletedTasks(): LiveData<List<Task>>
}
