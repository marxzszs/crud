# StudySync — Academic Task & Deadline Manager

A midterm Android project (Kotlin) for BSIT coursework at Binangonan Catholic College.
Tracks assignments, due dates, and completion status across your subjects.

## How to open it

1. Launch Android Studio → **File > Open** → select the `StudySync` folder.
2. Let Gradle sync. This project has **no committed Gradle wrapper**, so Android Studio
   will use its own bundled Gradle, or may prompt *"Gradle wrapper is missing, create one?"*
   — click **OK**. If it instead suggests upgrading the Android Gradle Plugin / Kotlin
   version to match your Studio release, accept the suggestion; that's normal and won't
   break anything here.
3. Run on an emulator or physical device (min SDK 26 / Android 8.0+).

## Where each required feature lives

| Requirement | Files |
|---|---|
| **Room Database (CRUD)** | `data/Task.kt` (entity), `data/TaskDao.kt` (Insert/Update/Delete/Query), `data/TaskDatabase.kt`, `data/TaskRepository.kt` |
| **RecyclerView** | `ui/home/TaskAdapter.kt`, `res/layout/item_task.xml`, wired up in `ui/home/HomeFragment.kt` |
| **Navigation Component** | `res/navigation/nav_graph.xml`, `res/menu/bottom_nav_menu.xml`, `MainActivity.kt` |
| **SharedPreferences** | `ui/settings/SettingsFragment.kt` (dark mode + default sort), read back in `MainActivity.kt` and `HomeFragment.kt` |

CRUD mapping specifically:
- **Create** → the Save button in `AddTaskFragment` when no task id was passed in.
- **Read** → `HomeFragment` observes `LiveData<List<Task>>` from the ViewModel and displays it via the RecyclerView.
- **Update** → tapping a row opens `AddTaskFragment` pre-filled for editing; the checkbox also updates `isCompleted` directly.
- **Delete** → swipe a row left/right (with an Undo snackbar).

## Screens

- **Home** — To-Do / Completed tabs, RecyclerView of tasks, FAB to add a task.
- **Add / Edit Task** — form with validation and a date picker.
- **Settings** — dark mode toggle and default sort order (by due date or by subject), both persisted with SharedPreferences.

## Notes / deliberate simplifications

- The bottom navigation has **Home** and **Settings** only (the original mockup's third
  "Calendar" tab isn't one of the four graded technical features, so it was left out to
  keep the scope focused — you can add a `CalendarFragment` the same way `SettingsFragment`
  was added if you want it for extra polish).
- No third-party icon library is used — the launcher icon and the FAB's "+" icon are
  hand-written vector drawables, so there are zero external asset downloads required.
- Dates are stored as epoch-millisecond `Long` values in Room (not formatted strings) so
  that "sort by due date" is chronologically correct.

## For your Step 6 recording

A clean run-through that hits every rubric point:
1. Add two or three tasks with different due dates and courses (shows **Create** + **Navigation** to the Add screen).
2. Show them listed and sorted on Home (shows **Read** + **RecyclerView**).
3. Tap a task to edit it, change the course name, save (shows **Update**).
4. Check a task complete, switch to the Completed tab (shows **Update** + tab filtering).
5. Swipe a task away to delete it (shows **Delete**).
6. Go to Settings, toggle Dark Mode, and switch the default sort order — then go back to Home to show both took effect (shows **SharedPreferences**).
7. Close and reopen the app to prove the data and the dark mode setting both persisted.
