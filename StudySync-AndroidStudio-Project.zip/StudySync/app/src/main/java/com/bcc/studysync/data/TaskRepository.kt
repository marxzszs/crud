package com.bcc.studysync.data

import androidx.lifecycle.LiveData

class TaskRepository(private val taskDao: TaskDao) {

    val pendingTasksByDate: LiveData<List<Task>> = taskDao.getPendingTasksByDate()
    val pendingTasksBySubject: LiveData<List<Task>> = taskDao.getPendingTasksBySubject()
    val completedTasks: LiveData<List<Task>> = taskDao.getCompletedTasks()

    suspend fun insertTask(task: Task) = taskDao.insertTask(task)

    suspend fun updateTask(task: Task) = taskDao.updateTask(task)

    suspend fun deleteTask(task: Task) = taskDao.deleteTask(task)

    suspend fun getTaskById(taskId: Int): Task? = taskDao.getTaskById(taskId)
}
