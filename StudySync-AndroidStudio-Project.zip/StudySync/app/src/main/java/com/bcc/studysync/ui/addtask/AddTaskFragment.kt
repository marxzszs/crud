package com.bcc.studysync.ui.addtask

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bcc.studysync.R
import com.bcc.studysync.data.Task
import com.bcc.studysync.databinding.FragmentAddTaskBinding
import com.bcc.studysync.util.Constants
import com.bcc.studysync.viewmodel.TaskViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class AddTaskFragment : Fragment() {

    private var _binding: FragmentAddTaskBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TaskViewModel by activityViewModels()
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    private val calendar = Calendar.getInstance()

    private var editingTaskId: Int = -1
    private var existingIsCompleted: Boolean = false
    private var selectedDateMillis: Long = 0L

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddTaskBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        editingTaskId = arguments?.getInt(Constants.ARG_TASK_ID, -1) ?: -1

        if (editingTaskId != -1) {
            binding.textScreenTitle.text = getString(R.string.edit_task_title)
            loadTaskForEditing(editingTaskId)
        }

        binding.editDueDate.setOnClickListener { showDatePicker() }
        binding.buttonSaveTask.setOnClickListener { saveTask() }
        binding.buttonCancelTask.setOnClickListener { findNavController().popBackStack() }
    }

    private fun loadTaskForEditing(taskId: Int) {
        viewLifecycleOwner.lifecycleScope.launch {
            val task = viewModel.getTaskById(taskId)
            task?.let {
                binding.editTaskName.setText(it.taskName)
                binding.editCourseName.setText(it.courseName)
                selectedDateMillis = it.dueDate
                existingIsCompleted = it.isCompleted
                calendar.timeInMillis = it.dueDate
                binding.editDueDate.setText(dateFormat.format(it.dueDate))
            }
        }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                calendar.set(year, month, dayOfMonth, 0, 0, 0)
                selectedDateMillis = calendar.timeInMillis
                binding.editDueDate.setText(dateFormat.format(calendar.time))
                binding.inputLayoutDueDate.error = null
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun saveTask() {
        val taskName = binding.editTaskName.text?.toString()?.trim().orEmpty()
        val courseName = binding.editCourseName.text?.toString()?.trim().orEmpty()

        var hasError = false

        if (taskName.isEmpty()) {
            binding.inputLayoutTaskName.error = getString(R.string.error_task_name_required)
            hasError = true
        } else {
            binding.inputLayoutTaskName.error = null
        }

        if (courseName.isEmpty()) {
            binding.inputLayoutCourseName.error = getString(R.string.error_course_name_required)
            hasError = true
        } else {
            binding.inputLayoutCourseName.error = null
        }

        if (selectedDateMillis == 0L) {
            binding.inputLayoutDueDate.error = getString(R.string.error_due_date_required)
            hasError = true
        }

        if (hasError) return

        if (editingTaskId != -1) {
            viewModel.updateTask(
                Task(
                    id = editingTaskId,
                    taskName = taskName,
                    courseName = courseName,
                    dueDate = selectedDateMillis,
                    isCompleted = existingIsCompleted
                )
            )
        } else {
            viewModel.insertTask(
                Task(
                    taskName = taskName,
                    courseName = courseName,
                    dueDate = selectedDateMillis
                )
            )
        }

        findNavController().popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
