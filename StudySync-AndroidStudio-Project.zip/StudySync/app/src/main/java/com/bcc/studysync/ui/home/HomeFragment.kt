package com.bcc.studysync.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bcc.studysync.R
import com.bcc.studysync.databinding.FragmentHomeBinding
import com.bcc.studysync.util.Constants
import com.bcc.studysync.viewmodel.TaskViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val viewModel: TaskViewModel by activityViewModels()
    private lateinit var adapter: TaskAdapter

    private var showingCompleted = false
    private var sortBySubject = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sortBySubject = requireContext()
            .getSharedPreferences(Constants.PREFS_NAME, 0)
            .getBoolean(Constants.KEY_SORT_BY_SUBJECT, false)

        adapter = TaskAdapter(
            onItemClick = { task ->
                findNavController().navigate(
                    R.id.action_home_to_addTask,
                    bundleOf(Constants.ARG_TASK_ID to task.id)
                )
            },
            onCheckedChange = { task, isChecked ->
                viewModel.updateTask(task.copy(isCompleted = isChecked))
            }
        )

        binding.recyclerViewTasks.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerViewTasks.adapter = adapter

        attachSwipeToDelete()

        binding.fabAddTask.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_addTask)
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                showingCompleted = tab.position == 1
                observeTasks()
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        observeTasks()
    }

    /** Switches which LiveData source is observed based on the selected tab + sort preference. */
    private fun observeTasks() {
        viewModel.pendingTasksByDate.removeObservers(viewLifecycleOwner)
        viewModel.pendingTasksBySubject.removeObservers(viewLifecycleOwner)
        viewModel.completedTasks.removeObservers(viewLifecycleOwner)

        val liveData = when {
            showingCompleted -> viewModel.completedTasks
            sortBySubject -> viewModel.pendingTasksBySubject
            else -> viewModel.pendingTasksByDate
        }

        liveData.observe(viewLifecycleOwner) { tasks ->
            adapter.submitList(tasks)
            val isEmpty = tasks.isNullOrEmpty()
            binding.textEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
            binding.textEmptyState.text = getString(
                if (showingCompleted) R.string.empty_completed else R.string.empty_todo
            )
        }
    }

    /** Swipe a row left or right to delete it, with an Undo option. */
    private fun attachSwipeToDelete() {
        val swipeHandler = object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.bindingAdapterPosition
                if (position == RecyclerView.NO_POSITION) return
                val removedTask = adapter.currentList[position]
                viewModel.deleteTask(removedTask)

                Snackbar.make(binding.root, R.string.task_deleted, Snackbar.LENGTH_LONG)
                    .setAction(R.string.undo) {
                        viewModel.insertTask(removedTask.copy(id = 0))
                    }.show()
            }
        }
        ItemTouchHelper(swipeHandler).attachToRecyclerView(binding.recyclerViewTasks)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
