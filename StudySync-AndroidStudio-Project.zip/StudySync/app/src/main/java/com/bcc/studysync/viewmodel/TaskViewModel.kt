package com.bcc.studysync.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.bcc.studysync.data.Task
import com.bcc.studysync.data.TaskDatabase
import com.bcc.studysync.data.TaskRepository
import kotlinx.coroutines.launch

class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TaskRepository

    val pendingTasksByDate: LiveData<List<Task>>
    val pendingTasksBySubject: LiveData<List<Task>>
    val completedTasks: LiveData<List<Task>>

    init {
        val dao = TaskDatabase.getDatabase(application).taskDao()
        repository = TaskRepository(dao)
        pendingTasksByDate = repository.pendingTasksByDate
        pendingTasksBySubject = repository.pendingTasksBySubject
        completedTasks = repository.completedTasks
    }

    fun insertTask(task: Task) = viewModelScope.launch {
        repository.insertTask(task)
    }

    fun updateTask(task: Task) = viewModelScope.launch {
        repository.updateTask(task)
    }

    fun deleteTask(task: Task) = viewModelScope.launch {
        repository.deleteTask(task)
    }

    suspend fun getTaskById(taskId: Int): Task? = repository.getTaskById(taskId)
}
