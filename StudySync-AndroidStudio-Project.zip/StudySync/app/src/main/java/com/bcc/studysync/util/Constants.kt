package com.bcc.studysync.util

object Constants {
    const val PREFS_NAME = "studysync_prefs"
    const val KEY_DARK_MODE = "dark_mode"
    const val KEY_SORT_BY_SUBJECT = "sort_by_subject"
    const val ARG_TASK_ID = "task_id"
}
